import java.io.File;
import java.io.*;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.*;
public class enc
{
	static Scanner sc=new Scanner(System.in);
	public static String filename;
	public static int rcb[][];
	public static int comb[];
	public static int rcbor[][];
	public static int height;
	public static int width;
	public enc(int height,int width)
	{
		rcb=new int[height][width];
		comb=new int[height*width*4];
		rcbor=new int[height][width];
	}
	public static void generating_values()
	{
		int i,k;
		double r=3.56,scale,temp=0.2;
		for(i=0;i<(height*width*4);i++)
		{
			temp=r*temp*(1-temp);
			scale = Math.pow(10, 8);
			temp=Math.round(temp * scale)/scale;
			k=(int)(temp*1000);
			k=k%255;
			comb[i]=k;
		}
	}
	public static void delete()
	{
		File f = null;
		f = new File(filename);
		f.delete();
		
	}
	public static int swap(int i,int j,int h)
	{
		return ((i+j)%h);
	}
	public static void transform()
	{
		int i,j,c;
		for(i=0;i<height;i++)
	    {
	    	c=swap(i,comb[i],height);
	    	for(j=0;j<width;j++)
	    	{
	    		int temp=rcb[i][j];
	    		rcb[i][j]=rcb[c][j];
	    		rcb[c][j]=temp;
	    	}	
	    }
	    for(i=0;i<width;i++)
	    {
	    	c=swap(i,comb[i],width);
	    	for(j=0;j<height;j++)
	    	{
	    		int temp=rcb[j][i];
	    		rcb[j][i]=rcb[j][c];
	    		rcb[j][c]=temp;
	    	}
	    }
	}
	public static void read()
	{
		int i=0,j;
	    BufferedImage img = null;
	    File f = null;

	    //read image
	    try
	    {
	      
	      filename=sc.nextLine();
	      f = new File(filename);
	      img = ImageIO.read(f);
	    }
	    catch(IOException e)
	    {
	      System.out.println(e);
	    }
	    width = img.getWidth();
	    height = img.getHeight();
	    //System.out.println(height+"    "+width);
	    for(i=0;i<height;i++)
	    {
	      for(j=0;j<width;j++)
	      {
	        int p = img.getRGB(j,i);
	        //System.out.println(j);
	        rcb[i][j]=p;
	        //rcbor[i][j]=p;
	      }
	    }

	}
	public static void transform1()
	{
		int i,j,c;
		for(i=height-1;i>=0;i--)
	    {
	    	c=swap(i,comb[i],height);
	    	for(j=width-1;j>=0;j--)
	    	{
	    		int temp=rcb[i][j];
	    		rcb[i][j]=rcb[c][j];
	    		rcb[c][j]=temp;
	    	}	
	    }
	    for(i=width-1;i>=0;i--)
	    {
	    	c=swap(i,comb[i],width);
	    	for(j=height-1;j>=0;j--)
	    	{
	    		int temp=rcb[j][i];
	    		rcb[j][i]=rcb[j][c];
	    		rcb[j][c]=temp;
	    		//System.out.println(rcb[j][i]);
	    	}
	    	
	    }
	}
	public static void perform_operation1()
	{
		int i=0;
		for(int y = height-1; y>=0; y--)
	    {
	      for(int x = width-1; x >=0; x--)
	      {
	    	  i=0;
	    	  int bac=rcb[y][x];
	    	  int a = (bac>>24)&0xff;
	          int r = (bac>>16)&0xff;
	          int g = (bac>>8)&0xff;
	          int b = bac&0xff;
	          a=(a-comb[i]+256)%256;
	          r=(r-comb[i+1]+256)%256;
	          g=(g-comb[i+2]+256)%256;
	          b=(b-comb[i+3]+256)%256;
	          i=i+4;
	          rcb[y][x]= (a<<24) | (r<<16) | (g<<8) | b;
	      }
	    }
	}
	public static void write()
	{
		BufferedImage img = null;
	    File f = null;
		int i,j;
		try
	    {
	      f = new File(filename);
	      img = ImageIO.read(f);
	    }
	    catch(IOException e)
	    {
	      System.out.println(e);
	    }
		for(i=0;i<height;i++)
	    {
	      for(j=0;j<width; j++)
	      {
	    	 img.setRGB(j, i, rcb[i][j]);
     	      }
	    }
		 try
		    {
		      f = new File("E:\\Network Security\\Output1.png");
		      ImageIO.write(img, "png", f);
		    }
		    catch(IOException e)
		    {
		      System.out.println(e);
		    }
	}
	public static void perform_operation()
	{
		int i=0;
		for(int y = 0; y < height; y++)
	    {
	      for(int x = 0; x < width; x++)
	      {
	    	  i=0;
	    	  int bac=rcb[y][x];
	    	  int a = (bac>>24)&0xff;
	          int r = (bac>>16)&0xff;
	          int g = (bac>>8)&0xff;
	          int b = bac&0xff;
	          a=(a+comb[i])%256;
	          r=(r+comb[i+1])%256;
	          g=(g+comb[i+2])%256;
	          b=(b+comb[i+3])%256;
	          i=i+4;
	          rcb[y][x]= (a<<24) | (r<<16) | (g<<8) | b;
	      }
	    }
	}
	public static void main(String args[])throws IOException
	  {
			int a,b,input,v;
			BufferedImage img = null;
			File f = null;
			String s,p,s1,p1;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the user name.");
			s=sc.nextLine();
			System.out.println("Enter the password");
			p=sc.nextLine();
			System.out.println("Enter File Name");
			filename=sc.nextLine();
			f = new File(filename);
			img = ImageIO.read(f);
			a = img.getWidth();
		    b = img.getHeight();
		    enc obj=new enc(b,a);
		    obj.read();
		    obj.generating_values();
		    obj.transform();
	        obj.perform_operation();
		    obj.write();
		    System.out.println("Do you want to decrypt the image.");
		    System.out.println("Press 1. for if you want.");
		    System.out.println("Press 2. if you do not want.");
		    v=sc.nextInt();
		    if(v==1)
		    {
		    	System.out.println("Enter the user name.");
		    	System.out.println("Enter the password");
		    	s1=sc.next();
				p1=sc.next();
				if(s.equals(s1)&&p.equals(p1))
				{
					filename="E:\\Network Security\\Output1.png";
					obj.read();
				    obj.generating_values();
				    obj.perform_operation1();
				    obj.transform1();
				    obj.write();
				}
				else
					System.out.println("Enter correct credintials.");	
		    }
		    
	  }	
}