# -*- coding: utf-8 -*-
"""
Created on Fri Oct 26 16:06:47 2018

@author: TheKa
"""
from PIL import Image
import numpy as np
import copy

##################################################
##################################################
###############################FOR DES###########
##################################################

uniKey = "1111111111"

def P_4(mat) :
    ##conducts p4
    P4 = [2,4,3,1]
    newMat = []
    
    for i in P4:
        newMat.append(mat[i-1])
    
    return newMat


def P_10(keyMat):
    ##conducts standard permutation on 10 bit key
    P10 = [3,5,2,7,4,10,1,9,8,6]
    newKeyMat = []
    
    for i in P10:
        newKeyMat.append(keyMat[i-1])
    
    return newKeyMat


def EP(matrix):
    ep = [4,1,2,3,2,3,4,1]
    newMat = []
    
    for i in ep:
        newMat.append(matrix[i-1])
        
    return newMat

def P_8(keyMat):
    ##Conduts P8 on 10 bit key permutation
    P8 = [6,3,7,4,8,5,10,9]
    newKeyMat = []
    
    for i in P8:
        newKeyMat.append(keyMat[i-1])
    
    return newKeyMat


def IP(matrix):
    newMat = []
    ip = [2,6,3,1,4,8,5,7]
    
    for i in ip:
        newMat.append(matrix[i-1])
    
    return newMat


def invIP(matrix):
    newMat = []
    iip = [4,1,3,5,7,2,8,6]
    
    for i in iip:
        newMat.append(matrix[i-1])
    
    return newMat

def l_shift(matrix,n):
    ##n left shifts on mat
    mat = copy.deepcopy(matrix)
    
    while(n>0):
        temp = mat[0]
        for i in range(0,len(mat)-1):
            mat[i] = mat[i+1]
        mat[len(mat)-1] = temp
        n-=1
    
    return mat

def split(matrix):
    ##devides matrix in 2 equal halfes
    mat1 = matrix[0:len(matrix)//2]
    mat2 = matrix[len(matrix)//2:len(matrix)]
    
    return [mat1,mat2]


def XOR(mat1,mat2):
    newMat = []
    
    for i in range(len(mat1)):
        newMat.append(str(( int(mat1[i])+int((mat2[i])) )%2))
    
    return newMat

def S(mat,n):
    ##does S0 or S1 of mat based on n
    S0 = [['01','00','11','10'],['11','10','01','00'],['00','10','01','11'],['11','01','11','10']]
    S1 = [['00','01','10','11'],['10','00','01','11'],['10','00','01','00'],['10','01','00','11']]
    Sn = [S0,S1]
    
    row = 2*int(mat[0]) + int(mat[3])
    col = 2*int(mat[1]) + int(mat[2])
    
    return Sn[n][row][col]

def encryptBlock(rMat,key):
    #conducts one round of encryption block with right side of plain text
    t_Mat = copy.deepcopy(rMat)
    t_Mat = EP(t_Mat)
    
    t_Mat = XOR(t_Mat,key)
    
    l_Mat,r_Mat = split(t_Mat)
       
    l_Mat = S(l_Mat,0)
    r_Mat = S(r_Mat,1)
    
    newMat = ''.join(l_Mat) + ''.join(r_Mat)    
    newMat = P_4(newMat)
    
    return newMat
    
def en(plainText,ukey):
    ##DES encryption
    global uniKey
    uniKey = ukey
    cipherText = copy.deepcopy(plainText)
    cipherText = IP(cipherText)
    
    l_Mat,r_Mat = split(cipherText)
    k1,k2 = keyGenrator()
    
    l_Mat = XOR(l_Mat,encryptBlock(r_Mat,k1))
    r_Mat = XOR(r_Mat,encryptBlock(l_Mat,k2))
    
    cipherText = ''.join(invIP(''.join(r_Mat) + ''.join(l_Mat)))
    
    return cipherText
  
 
def dec(cipherText,ukey):
    ##DES encryption
    global uniKey
    uniKey = ukey
    plainText = copy.deepcopy(cipherText)
    plainText = IP(plainText)
    
    l_Mat,r_Mat = split(plainText)
    k1,k2 = keyGenrator()
    
    l_Mat = XOR(l_Mat,encryptBlock(r_Mat,k2))
    r_Mat = XOR(r_Mat,encryptBlock(l_Mat,k1))
    
    plainText = ''.join(invIP(''.join(r_Mat) + ''.join(l_Mat)))
    
    return plainText

    
def keyGenrator():
    ##genrates key for S-DES enctiption based on initial value of key
    global unikey
    key = uniKey
    
    key = P_10(key)
    
    l_key,r_key = split(key)
    l_key,r_key = l_shift(l_key,1),l_shift(r_key,1)
    
    key = l_key+r_key
    k1 = P_8(key) ##first key
    
    l_key,r_key = split(key)
    l_key,r_key = l_shift(l_key,2),l_shift(r_key,2)
    
    key = l_key+r_key
    k2 = P_8(key)##second key
    
    return [k1,k2]



#######################################################################
#####################################################################

##taking input file and opening it
fileName = input("Give image File to open : ")
img = Image.open(fileName)
img.show()

##Converting image
imgArray = np.asarray(img)
imgArray = imgArray.tolist()
#print(imgArray)

pas = input("Give password (10 bit binary no) : ")


encArray = []

ch = int(input("\n1. To Encrypt\n2. To Decrypt \n \n Answer : "))

#################Incripting Image##############################


if ch == 1 :
    for i in imgArray:
        temp = []
        for j in i:
            
            gamma = ["{0:08b}".format(j[0]),"{0:08b}".format(j[1]),"{0:08b}".format(j[2]),]
            
            a = int(en(en(en(gamma[0],"1111100000"),pas),"1010101010"),2)%256
            b = int(en(en(en(gamma[1],"1011001010"),pas),"1110011100"),2)%256
            c = int(en(en(en(gamma[2],"0001010011"),pas),"1000011111"),2)%256
            temp.append([a,b,c])
        encArray.append(temp)

#################Decrypting Image#####################################3
    
# 
if ch == 2:
    for i in imgArray:
        temp = []
        for j in i:
        
            gamma = ["{0:08b}".format(j[0]),"{0:08b}".format(j[1]),"{0:08b}".format(j[2]),]
        
            a = int(dec(dec(dec(gamma[0],"1010101010"),pas),"1111100000"),2)%256
            b = int(dec(dec(dec(gamma[1],"1110011100"),pas),"1011001010"),2)%256
            c = int(dec(dec(dec(gamma[2],"1000011111"),pas),"0001010011"),2)%256
            temp.append([a,b,c])
        encArray.append(temp)


##Saving encrypted Image 
newImage = Image.new('RGB',(len(encArray[0]),len(encArray)))
newImage.putdata([tuple(p) for row in encArray for p in row])
newImage.show()
saveName = input("Give name to save file : ")
newImage.save(saveName)
